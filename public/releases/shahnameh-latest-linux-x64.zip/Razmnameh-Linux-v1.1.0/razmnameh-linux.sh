#!/usr/bin/env bash
set -e
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/app" && pwd )"
PORT=4591
echo "Starting Razmnameh: Legends of Shahnameh (v1.1.0)..."
python3 -m http.server $PORT --directory "$DIR" >/dev/null 2>&1 &
SERVER_PID=$!
sleep 0.6
if command -v google-chrome >/dev/null 2>&1; then
  google-chrome --app="http://127.0.0.1:$PORT" --window-size=1280,720
elif command -v chromium-browser >/dev/null 2>&1; then
  chromium-browser --app="http://127.0.0.1:$PORT" --window-size=1280,720
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://127.0.0.1:$PORT"
  wait $SERVER_PID
fi
kill $SERVER_PID 2>/dev/null || true
