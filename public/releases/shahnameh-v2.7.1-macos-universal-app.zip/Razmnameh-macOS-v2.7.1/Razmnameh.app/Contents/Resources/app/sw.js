/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "27ceaf5e342e3a0916ddb93b5466e6d7"
  }, {
    "url": "pwa-512x512.png",
    "revision": "894788e1db05717c74110be4653a3b24"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f05f85e18c47a03d8bf0da3ed6126fe1"
  }, {
    "url": "index.html",
    "revision": "e439b880b099119af9b2b9bb45810d96"
  }, {
    "url": "icon.svg",
    "revision": "9006bbaaf4476ea3bf1b4e5112ac7880"
  }, {
    "url": "favicon.ico",
    "revision": "adca22443483338685a6478ebdbdf2b7"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "d7019f4646d2a7b3e42685b9ce16fbdf"
  }, {
    "url": "assets/index-DkmfdEec.js",
    "revision": null
  }, {
    "url": "assets/index-ClPw7OMq.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "d7019f4646d2a7b3e42685b9ce16fbdf"
  }, {
    "url": "favicon.ico",
    "revision": "adca22443483338685a6478ebdbdf2b7"
  }, {
    "url": "icon.svg",
    "revision": "9006bbaaf4476ea3bf1b4e5112ac7880"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f05f85e18c47a03d8bf0da3ed6126fe1"
  }, {
    "url": "pwa-512x512.png",
    "revision": "894788e1db05717c74110be4653a3b24"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "27ceaf5e342e3a0916ddb93b5466e6d7"
  }, {
    "url": "manifest.webmanifest",
    "revision": "4857a77aec1ebc8cbd5b3598a237d1c1"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
