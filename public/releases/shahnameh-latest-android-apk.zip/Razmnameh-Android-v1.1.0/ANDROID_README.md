# راهنمای بیلد و نصب اندروید (Android APK / AAB) — نسخه v1.1.0

## روش اول: بیلد خودکار با اسکریپت یک‌کلیکی
در ترمینال دستور زیر را اجرا کنید تا فایل `app-debug.apk` به طور خودکار ساخته شود:
```bash
./build-android-apk.sh
```

## روش دوم: باز کردن در Android Studio
```bash
npm install @capacitor/core @capacitor/android @capacitor/cli
npx cap add android
npx cap sync android
npx cap open android
```
