#!/usr/bin/env bash
set -e
echo "=========================================================="
echo "🤖 Building Razmnameh Android APK (v1.1.0)"
echo "=========================================================="
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android || true
npx cap sync android
if [ -d "android" ]; then
  cd android && ./gradlew assembleDebug
  echo "✅ APK built at: android/app/build/outputs/apk/debug/app-debug.apk"
fi
