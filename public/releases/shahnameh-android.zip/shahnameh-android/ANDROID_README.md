# راهنمای اجرای خروجی اندروید (Android APK / AAB) - نسخه v1.0.5
این بسته شامل کلیه فایل‌های وب کامپایل‌شده نسخه v1.0.5 (استایل نقاشی قهوه‌خانه‌ای و موتور روایت StoryLogicManager) به همراه تنظیمات Capacitor برای سیستم‌عامل اندروید است.

## مراحل ساخت فایل نصب APK در Android Studio:
۱. پیش‌نیاز: نصب Node.js و Android Studio
۲. اجرای دستور نصب پیش‌نیازها:
   npm install @capacitor/core @capacitor/android @capacitor/cli
۳. مقداردهی اولیه پلتفرم اندروید:
   npx cap add android
۴. همگام‌سازی فایل‌های بازی با اندروید:
   npx cap sync android
۵. باز کردن پروژه در محیط اندروید استودیو:
   npx cap open android
۶. از منوی Build گزینه Build APK یا Generate Signed Bundle را انتخاب فرمایید.
