@echo off
title Razmnameh: Legends of Shahnameh v2.7.1
echo ==========================================================
echo   Razmnameh: Legends of Shahnameh (v2.7.1) - Windows
echo ==========================================================
if exist "node_modules\.bin\electron.cmd" (
    start "" "node_modules\.bin\electron.cmd" .
    exit /b 0
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    start /b python -m http.server 4589 --directory app >nul 2>nul
    timeout /t 1 /nobreak >nul
    start "" msedge --app=http://127.0.0.1:4589 --start-fullscreen
    exit /b 0
)
where npx >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    npx --yes serve app -l 4589
    exit /b 0
)
start "" "app\index.html"
