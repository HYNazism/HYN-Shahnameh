# راهنمای اجرای نسخه دسکتاپ (Windows / macOS / Linux) - نسخه v1.0.5

## روش اجرا:
۱. در این پوشه دستور زیر را اجرا کنید:
   npm install electron
۲. برای اجرای بازی:
   npx electron .
